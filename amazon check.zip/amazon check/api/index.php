<?php
error_reporting(0);

// antispam not clean...

header("Location: ../");

?>