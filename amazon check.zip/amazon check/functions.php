<?php
// functions.php

function getCardInfo($cardNumber) {
    $bin = substr($cardNumber, 0, 6); // Tomar los primeros 6 dígitos (BIN)
    $cacheFile = "bin_cache/$bin.json"; // Archivo de caché para este BIN

    // Verificar si el archivo de caché existe
    if (file_exists($cacheFile)) {
        $cachedData = json_decode(file_get_contents($cacheFile), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $cachedData; // Devolver los datos del caché
        }
    }

    // Consultar la API (ejemplo con Binlist)
    $url = "https://lookup.binlist.net/$bin";
    $response = @file_get_contents($url);

    if ($response === FALSE) {
        // Si la API no responde, devolver datos predeterminados
        return [
            'type' => 'Crédito/Débito',
            'country' => 'Internacional',
            'bank' => 'Banco no disponible',
            'scheme' => 'Visa/Mastercard'
        ];
    }

    // Decodificar la respuesta JSON
    $data = json_decode($response, true);

    // Normalizar la estructura del JSON
    $normalizedData = [
        'type' => $data['type'] ?? 'Crédito/Débito',
        'country' => $data['country']['name'] ?? 'Internacional',
        'bank' => $data['bank']['name'] ?? 'Banco no disponible',
        'scheme' => $data['scheme'] ?? 'Visa/Mastercard'
    ];

    // Guardar la respuesta normalizada en el caché
    file_put_contents($cacheFile, json_encode($normalizedData));

    return $normalizedData;
}
?>