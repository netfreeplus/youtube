<?php
// bin_lookup.php

// Incluir la función getCardInfo desde functions.php
require_once 'functions.php';

// Iniciar sesión (si no está ya iniciada)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar si se envió un BIN para consultar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bin = substr($_POST['bin'], 0, 6); // Tomar solo los primeros 6 dígitos
    if (strlen($bin) === 6 && is_numeric($bin)) {
        // Obtener información del BIN (usando la función existente)
        $cardInfo = getCardInfo($bin . '0000000000'); // Agregar dígitos ficticios para completar el número
    } else {
        $error = "El BIN debe tener exactamente 6 dígitos numéricos.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Consulta de BIN</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Estilos personalizados -->
    <style>
        body {
            background-color: #0f0c29;
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .form-control {
            background-color: #1a1a2e;
            color: #e0e7ff;
            border: 1px solid rgba(81, 203, 238, 0.3);
        }
        .btn-primary {
            background-color: #00b4d8;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0096c7;
        }
        .alert {
            margin-top: 20px;
        }
        h1, h3 {
            color: #00b4d8;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Botón para regresar al Checker -->
        <a href="index.php" class="btn btn-dark shadow mb-3">
            <i class="fa-solid fa-arrow-left"></i> Volver al Checker
        </a>

        <h1><i class="fa-solid fa-magnifying-glass"></i> Consulta de BIN</h1>
        <form method="POST">
            <div class="form-group">
                <label for="bin">Ingresa los primeros 6 dígitos de la tarjeta:</label>
                <input type="text" id="bin" name="bin" class="form-control" maxlength="6" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-search"></i> Buscar
            </button>
        </form>

        <?php if (isset($cardInfo)): ?>
            <div class="mt-4">
                <h3><i class="fa-solid fa-info-circle"></i> Resultados:</h3>
                <p><strong>Banco:</strong> <?php echo $cardInfo['bank']; ?></p>
                <p><strong>País:</strong> <?php echo $cardInfo['country']; ?></p>
                <p><strong>Tipo:</strong> <?php echo $cardInfo['type']; ?></p>
                <p><strong>Red:</strong> <?php echo $cardInfo['scheme']; ?></p>
            </div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger mt-4">
                <i class="fa-solid fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>